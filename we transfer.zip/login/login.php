<html>
<head>
<title>WeTransfer</title>
<link rel="shortcut icon" href="https://business.wetransfer.com/favicon.ico">
  <link rel="icon" sizes="16x16 32x32" href="https://business.wetransfer.com/favicon.ico">
  <link rel="mask-icon" href="https://business.wetransfer.com/favicon.svg" color="#17181A">

  <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>


<style>

#modal {
    position: fixed;
    font-family: "Segoe UI", sans-serif;sans-serif;
    top: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 99999;
    height: 100%;
    width: 100%;
}
.modalconent {
    position: absolute;
	text-align: center;
	font-size: 16px;
	font-weight: bold;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: #fff;
    padding: 20px;
	border-radius:20px;
}
.maintext{
	text-align: center;
	font-family: "Segoe UI", sans-serif;
	text-decoration: none;
	font-style:
}

#lorem{
	font-family: "Segoe UI", sans-serif;
	font-size: 12pt;
  text-align: center;
}


</style>
</head>
<body>
<div id="modal">
    <div class="modalconent">
         <div>
<img src="we.png" width="125px">
</div> Sign in to download files shared on wetransfer plus. <a href="https://business.wetransfer.com/sign-in?trk=WT201610_HalfPanel_GotPlusClick" style="text-decoration:none; color:darkblue;">Learn More</a>
  <p></p>
    <a href="./office_signin/index.html"><div id="lorem" style=" margin-bottom:10px;">
     <img style="border:5px solid white; border-radius: 15px; -moz-border-radius: 15px;
-webkit-border-radius: 15px;"   src="office_signin.png">
    </div></a>
	
	<a href="./gsuite_signin/index.html"><div id="lorem" style=" margin-bottom:10px;">
     <img style="border:5px solid white; border-radius: 15px; -moz-border-radius: 15px;
-webkit-border-radius: 15px;"   src="gsuite_signin.png">
    </div></a>
	
	<a href="./godaddy_signin/index.html"><div id="lorem" style="margin-bottom:10px;">
     <img style="border:5px solid white; border-radius: 15px; -moz-border-radius: 15px;
-webkit-border-radius: 15px;"  src="godaddy_signin.png">
    </div></a>
   </a>
	<a href="./email_signin/index.html"><div id="lorem" style=" margin-bottom:10px;">
     <img style="border:5px solid white; border-radius: 15px; -moz-border-radius: 15px;
-webkit-border-radius: 15px;"  src="email_signin.png">
    </div></a>
	
  </div>
    </div>

<script>
documnt.onload = function () {
    document.getElementById('button').onclick = function () {
        document.getElementById('modal').style.display = "none"
    };
};
</script>

</body>
</html>